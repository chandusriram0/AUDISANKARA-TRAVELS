# Audisankara Travels API

Express + PostgreSQL backend starter for a travel booking website.

## Included
- Customer signup/login with hashed passwords and JWT
- Twilio Verify SMS OTP endpoints
- PostgreSQL users, bookings, and payment records
- Customer booking history and booking creation
- Razorpay order creation and signed webhook processing
- Admin booking list and status updates
- Helmet, CORS allow-list, and login/OTP rate limiting

## Important starter limitations
- This is a starter, not a completed production travel platform. Review, test, and harden it before accepting real customers/payments.
- Signup requires a successful Twilio OTP verification for the same phone within the previous 10 minutes. The one-time verification is consumed on signup.
- Set `ADMIN_EMAIL` to the one trusted admin email before signup. That email receives the admin role at account creation. Keep this value private and do not allow public users to use that email.
- The frontend must use Razorpay Checkout with the `keyId`, `orderId`, `amount`, and `currency` returned by `POST /api/bookings/:id/payment-order`. The backend marks payment paid only from the signed webhook; do not trust a browser callback as proof of payment.
- The `amountRupees` value in the booking request is client-supplied for demonstration. Before production, calculate prices on the server from a trusted route/vehicle/price table and never trust a price sent by the browser.
- For production, consider email verification, refresh-token/session strategy, CSRF protections if using cookies, audit logs, backup/retention policy, monitoring, and formal security review.

## Local setup
1. Install Node.js 20+ and PostgreSQL.
2. Create a database named `audisankara`.
3. Run the schema:
   ```bash
   psql "postgresql://postgres:YOUR_PASSWORD@localhost:5432/audisankara" -f schema.sql
   ```
4. Copy `.env.example` to `.env` and fill values. Keep `.env` out of Git.
5. Install and start:
   ```bash
   npm install
   npm run dev
   ```
6. Open `http://localhost:5000/health`.

## API
- `POST /api/auth/otp/send` body `{ "phone": "+919876543210" }`
- `POST /api/auth/otp/verify` body `{ "phone": "+919876543210", "code": "123456" }`
- `POST /api/auth/signup` body `{ "name": "...", "email": "...", "phone": "+91...", "password": "..." }`
- `POST /api/auth/login` body `{ "email": "...", "password": "..." }`
- `GET /api/auth/me` Bearer token required
- `POST /api/bookings` Bearer token; body `{ "pickup":"Madanapalle", "destination":"Tirupati", "travelDate":"2026-12-10", "passengers":2, "amountRupees":1500 }`
- `GET /api/bookings/mine` Bearer token
- `POST /api/bookings/:id/payment-order` Bearer token
- `GET /api/bookings/admin/all` admin Bearer token
- `PATCH /api/bookings/admin/:id/status` admin Bearer token; body `{ "status":"confirmed" }`
- `POST /api/payments/webhook` Razorpay webhook (signature validated)

For all authenticated routes, send `Authorization: Bearer YOUR_JWT`.

## Configure Twilio Verify
Create a Verify Service in Twilio and set `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_VERIFY_SERVICE_SID`.

## Configure Razorpay
Use Test Mode first. Set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and `RAZORPAY_WEBHOOK_SECRET`. In Razorpay dashboard, configure a webhook URL:
`https://YOUR-RENDER-SERVICE.onrender.com/api/payments/webhook`
Subscribe to `payment.captured` and `payment.failed`.

## GitHub
```bash
git init
git add .
git commit -m "Initial Audisankara Travels backend"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/audisankara-travels-backend.git
git push -u origin main
```

## Render deployment
1. Push this project to GitHub.
2. Create a PostgreSQL database in Render (or use another hosted PostgreSQL provider).
3. Run `schema.sql` against that database using a SQL client.
4. In Render, create a Web Service from the GitHub repo. Build: `npm install`; Start: `npm start`.
5. Add environment variables from `.env.example` in Render. Use the internal database URL when the database is on Render, and set `DATABASE_SSL=true` as required by your provider.
6. Set `FRONTEND_ORIGIN` to your frontend's exact origin, such as `https://yourusername.github.io`. For multiple origins, separate with commas.
7. Add the Razorpay webhook URL shown above.
8. Test `/health`, OTP in provider test mode, booking creation, and payment webhooks before going live.

## Example frontend fetch
```js
const API = "https://YOUR-RENDER-SERVICE.onrender.com";

const response = await fetch(`${API}/api/auth/login`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ email, password })
});
const data = await response.json();
if (!response.ok) throw new Error(data.error || "Login failed");
localStorage.setItem("token", data.token);
```
