function getVerifyClient() {
  const { TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_VERIFY_SERVICE_SID } = process.env;
  if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_VERIFY_SERVICE_SID) {
    const err = new Error('Phone verification is not configured on the server.');
    err.status = 503;
    throw err;
  }
  const twilio = require('twilio')(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
  return twilio.verify.v2.services(TWILIO_VERIFY_SERVICE_SID);
}

async function sendCode(phone) {
  return getVerifyClient().verifications.create({ to: phone, channel: 'sms' });
}

async function checkCode(phone, code) {
  const result = await getVerifyClient().verificationChecks.create({ to: phone, code });
  return result.status === 'approved';
}

module.exports = { sendCode, checkCode };
