const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { sendCode, checkCode } = require('../services/otp');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

function signToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: '2h', issuer: 'audisankara-travels' }
  );
}

function publicUser(user) {
  return {
    id: user.id, name: user.name, email: user.email, phone: user.phone,
    role: user.role, phoneVerified: user.phone_verified
  };
}

// Send OTP before signup or to verify a registered account's phone.
router.post('/otp/send', async (req, res, next) => {
  try {
    const phone = String(req.body.phone || '').trim();
    if (!/^\+[1-9]\d{7,14}$/.test(phone)) {
      return res.status(400).json({ error: 'Use international phone format, e.g. +919876543210.' });
    }
    await sendCode(phone);
    res.json({ message: 'Verification code sent if the number is eligible.' });
  } catch (e) { next(e); }
});

router.post('/otp/verify', async (req, res, next) => {
  try {
    const phone = String(req.body.phone || '').trim();
    const code = String(req.body.code || '').trim();
    if (!/^\+[1-9]\d{7,14}$/.test(phone) || !/^\d{4,10}$/.test(code)) {
      return res.status(400).json({ error: 'A valid phone number and verification code are required.' });
    }
    const approved = await checkCode(phone, code);
    if (!approved) return res.status(400).json({ error: 'Invalid or expired verification code.' });
    await db.query(
      `INSERT INTO phone_verifications (phone, verified_until, consumed_at)
       VALUES ($1, NOW() + INTERVAL '10 minutes', NULL)
       ON CONFLICT (phone) DO UPDATE SET
         verified_until = EXCLUDED.verified_until, consumed_at = NULL`,
      [phone]
    );
    await db.query('UPDATE users SET phone_verified = TRUE WHERE phone = $1', [phone]);
    const result = await db.query('SELECT id FROM users WHERE phone = $1', [phone]);
    res.json({
      verified: true,
      accountExists: result.rowCount > 0,
      message: result.rowCount ? 'Phone verified.' : 'Phone verified. Complete signup within 10 minutes.'
    });
  } catch (e) { next(e); }
});

router.post('/signup', async (req, res, next) => {
  try {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const phone = String(req.body.phone || '').trim();
    const password = String(req.body.password || '');
    if (name.length < 2 || name.length > 120) return res.status(400).json({ error: 'Name must be 2–120 characters.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
    if (!/^\+[1-9]\d{7,14}$/.test(phone)) return res.status(400).json({ error: 'Use international phone format, e.g. +919876543210.' });
    if (password.length < 10 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) {
      return res.status(400).json({ error: 'Password must be at least 10 characters and include a letter and a number.' });
    }
    const verified = await db.query(
      `SELECT phone FROM phone_verifications
       WHERE phone = $1 AND verified_until > NOW() AND consumed_at IS NULL`,
      [phone]
    );
    if (!verified.rowCount) {
      return res.status(403).json({ error: 'Verify this phone by OTP first. Verification expires after 10 minutes.' });
    }
    const passwordHash = await bcrypt.hash(password, 12);
    const role = email === String(process.env.ADMIN_EMAIL || '').trim().toLowerCase() ? 'admin' : 'customer';
    const client = await db.pool.connect();
    let user;
    try {
      await client.query('BEGIN');
      const challenge = await client.query(
        `SELECT phone FROM phone_verifications
         WHERE phone = $1 AND verified_until > NOW() AND consumed_at IS NULL
         FOR UPDATE`,
        [phone]
      );
      if (!challenge.rowCount) {
        await client.query('ROLLBACK');
        return res.status(403).json({ error: 'Phone verification expired or already used. Verify again.' });
      }
      const created = await client.query(
        `INSERT INTO users (name, email, phone, password_hash, role, phone_verified)
         VALUES ($1,$2,$3,$4,$5,TRUE)
         RETURNING id, name, email, phone, role, phone_verified`,
        [name, email, phone, passwordHash, role]
      );
      await client.query(
        'UPDATE phone_verifications SET consumed_at = NOW() WHERE phone = $1',
        [phone]
      );
      await client.query('COMMIT');
      user = created.rows[0];
    } catch (err) {
      await client.query('ROLLBACK');
      throw err;
    } finally {
      client.release();
    }
    res.status(201).json({ user: publicUser(user), token: signToken(user), message: 'Account created and phone verified.' });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'That email or phone number is already registered.' });
    next(e);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const result = await db.query('SELECT * FROM users WHERE email = $1', [email]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }
    res.json({ user: publicUser(user), token: signToken(user) });
  } catch (e) { next(e); }
});

router.get('/me', authenticate, async (req, res, next) => {
  try {
    const result = await db.query(
      'SELECT id, name, email, phone, role, phone_verified FROM users WHERE id = $1',
      [req.user.id]
    );
    if (!result.rowCount) return res.status(404).json({ error: 'User not found.' });
    res.json({ user: publicUser(result.rows[0]) });
  } catch (e) { next(e); }
});

module.exports = router;
