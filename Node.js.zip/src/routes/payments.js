const express = require('express');
const crypto = require('crypto');
const db = require('../db');

const router = express.Router();

// Razorpay webhooks must receive the exact raw request bytes.
// The server registers this route with express.raw() before express.json().
router.post('/webhook', async (req, res, next) => {
  try {
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
    if (!secret) return res.status(503).send('Webhook not configured');
    const signature = req.headers['x-razorpay-signature'];
    const expected = crypto.createHmac('sha256', secret).update(req.body).digest('hex');
    const a = Buffer.from(String(signature || ''), 'utf8');
    const b = Buffer.from(expected, 'utf8');
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      return res.status(400).send('Invalid signature');
    }

    const event = JSON.parse(req.body.toString('utf8'));
    if (event.event === 'payment.captured') {
      const payment = event.payload?.payment?.entity;
      const orderId = payment?.order_id;
      if (orderId) {
        await db.query('BEGIN');
        try {
          const p = await db.query(
            `UPDATE payments SET provider_payment_id = $1, status = 'paid', updated_at = NOW()
             WHERE provider_order_id = $2 RETURNING booking_id`,
            [payment.id, orderId]
          );
          if (p.rowCount) {
            await db.query("UPDATE bookings SET status = 'confirmed' WHERE id = $1", [p.rows[0].booking_id]);
          }
          await db.query('COMMIT');
        } catch (err) {
          await db.query('ROLLBACK');
          throw err;
        }
      }
    } else if (event.event === 'payment.failed') {
      const payment = event.payload?.payment?.entity;
      if (payment?.order_id) {
        await db.query(
          `UPDATE payments SET status = 'failed', updated_at = NOW()
           WHERE provider_order_id = $1 AND status <> 'paid'`,
          [payment.order_id]
        );
      }
    }
    res.json({ received: true });
  } catch (e) { next(e); }
});

module.exports = router;
