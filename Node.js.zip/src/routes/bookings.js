const express = require('express');
const db = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { getRazorpay } = require('../services/payments');

const router = express.Router();
router.use(authenticate);

router.post('/', async (req, res, next) => {
  try {
    const { pickup, destination, travelDate, passengers, notes, amountRupees } = req.body;
    const count = Number(passengers);
    const amountPaise = Math.round(Number(amountRupees) * 100);
    if (!req.user.id) return res.status(401).json({ error: 'Please sign in.' });
    const userResult = await db.query('SELECT phone_verified FROM users WHERE id = $1', [req.user.id]);
    if (!userResult.rowCount || !userResult.rows[0].phone_verified) {
      return res.status(403).json({ error: 'Verify your phone before making a booking.' });
    }
    if (typeof pickup !== 'string' || pickup.trim().length < 2 ||
        typeof destination !== 'string' || destination.trim().length < 2) {
      return res.status(400).json({ error: 'Pickup and destination are required.' });
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(travelDate)) ||
        Number.isNaN(Date.parse(`${travelDate}T00:00:00Z`)) ||
        String(travelDate) < new Date().toISOString().slice(0,10)) {
      return res.status(400).json({ error: 'Choose a valid travel date that is not in the past.' });
    }
    if (!Number.isInteger(count) || count < 1 || count > 20) return res.status(400).json({ error: 'Passengers must be between 1 and 20.' });
    if (!Number.isSafeInteger(amountPaise) || amountPaise < 100 || amountPaise > 50000000) {
      return res.status(400).json({ error: 'Booking amount must be between ₹1 and ₹5,00,000.' });
    }
    const result = await db.query(
      `INSERT INTO bookings (user_id, pickup, destination, travel_date, passengers, notes, amount_paise)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       RETURNING id, pickup, destination, travel_date, passengers, notes, amount_paise, status, created_at`,
      [req.user.id, pickup.trim(), destination.trim(), travelDate, count, String(notes || '').slice(0,1000), amountPaise]
    );
    res.status(201).json({ booking: result.rows[0] });
  } catch (e) { next(e); }
});

router.get('/mine', async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT b.*, p.status AS payment_status, p.provider_order_id
       FROM bookings b LEFT JOIN payments p ON p.booking_id = b.id
       WHERE b.user_id = $1 ORDER BY b.created_at DESC`,
      [req.user.id]
    );
    res.json({ bookings: result.rows });
  } catch (e) { next(e); }
});

router.post('/:id/payment-order', async (req, res, next) => {
  try {
    const bookingId = Number(req.params.id);
    if (!Number.isSafeInteger(bookingId) || bookingId < 1) return res.status(400).json({ error: 'Invalid booking ID.' });
    const result = await db.query('SELECT * FROM bookings WHERE id = $1 AND user_id = $2', [bookingId, req.user.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Booking not found.' });
    const booking = result.rows[0];
    if (booking.status === 'cancelled') return res.status(400).json({ error: 'Cancelled bookings cannot be paid.' });
    const existing = await db.query('SELECT * FROM payments WHERE booking_id = $1', [bookingId]);
    if (existing.rowCount && existing.rows[0].status === 'paid') return res.status(409).json({ error: 'This booking is already paid.' });

    const order = await getRazorpay().orders.create({
      amount: booking.amount_paise,
      currency: 'INR',
      receipt: `travel_${booking.id}`,
      notes: { bookingId: String(booking.id), userId: String(req.user.id) }
    });
    await db.query(
      `INSERT INTO payments (booking_id, provider_order_id, amount_paise, status)
       VALUES ($1,$2,$3,'created')
       ON CONFLICT (booking_id) DO UPDATE SET provider_order_id = EXCLUDED.provider_order_id,
       amount_paise = EXCLUDED.amount_paise, status = 'created', updated_at = NOW()`,
      [booking.id, order.id, booking.amount_paise]
    );
    res.status(201).json({
      keyId: process.env.RAZORPAY_KEY_ID,
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
      bookingId: booking.id
    });
  } catch (e) { next(e); }
});

// Admin-only: list bookings and update booking status.
router.get('/admin/all', requireAdmin, async (req, res, next) => {
  try {
    const result = await db.query(
      `SELECT b.*, u.name AS customer_name, u.email AS customer_email, u.phone AS customer_phone,
              p.status AS payment_status, p.provider_payment_id
       FROM bookings b JOIN users u ON u.id = b.user_id
       LEFT JOIN payments p ON p.booking_id = b.id
       ORDER BY b.created_at DESC LIMIT 500`
    );
    res.json({ bookings: result.rows });
  } catch (e) { next(e); }
});

router.patch('/admin/:id/status', requireAdmin, async (req, res, next) => {
  try {
    const allowed = ['pending','confirmed','cancelled','completed'];
    const status = String(req.body.status || '');
    if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid booking status.' });
    const result = await db.query('UPDATE bookings SET status = $1 WHERE id = $2 RETURNING *', [status, req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: 'Booking not found.' });
    res.json({ booking: result.rows[0] });
  } catch (e) { next(e); }
});

module.exports = router;
