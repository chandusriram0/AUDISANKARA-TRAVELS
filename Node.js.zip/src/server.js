require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const fs = require('fs');
const path = require('path');
const db = require('./db');

const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({
  origin: (process.env.FRONTEND_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean),
  methods: ['GET','POST','PATCH','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization']
}));

// Keep this raw webhook route before express.json() for signature validation.
app.use('/api/payments', express.raw({ type: 'application/json', limit: '1mb' }), require('./routes/payments'));
app.use(express.json({ limit: '100kb' }));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false });
app.use('/api/auth', authLimiter, require('./routes/auth'));
app.use('/api/bookings', require('./routes/bookings'));

app.get('/health', async (_req, res) => {
  try {
    await db.query('SELECT 1');
    res.json({ status: 'ok', service: 'audisankara-travels-api', database: 'connected' });
  } catch {
    res.status(503).json({ status: 'error', database: 'unavailable' });
  }
});

app.get('/', (_req, res) => res.json({ name: 'Audisankara Travels API', health: '/health' }));

app.use((err, _req, res, _next) => {
  console.error(err.message || err);
  const status = Number(err.status) || 500;
  res.status(status).json({
    error: status >= 500 ? 'Server error. Check deployment logs and configuration.' : err.message
  });
});

const port = Number(process.env.PORT || 5000);
if (require.main === module) {
  if (!process.env.DATABASE_URL) {
    console.error('DATABASE_URL is required.');
    process.exit(1);
  }
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
    console.error('JWT_SECRET must be at least 32 characters.');
    process.exit(1);
  }
  app.listen(port, () => console.log(`Audisankara API listening on ${port}`));
}
module.exports = app;
